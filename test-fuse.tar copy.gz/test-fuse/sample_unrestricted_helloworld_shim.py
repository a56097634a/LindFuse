import dylink_portability

dylink_portability.run_unrestricted_repy_code("sample_helloworld_shim_app.repy", [1, 2])
